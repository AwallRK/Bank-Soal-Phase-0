// =====

/*
  Kamu sedang bepergian, kamu ingin masuk tol jakarta-bogor-ciawi, tapi ada pengecekan terlebih dahulu
  1. Jika kamu menggunakan motor, dipersilahkan putar balik, jika tidak, kamu boleh menggunakan tol
  2. Saat menggunakan tol, jika kendaraan kamu bergolongan 1, dikenakan biaya 7000
  3. Jika kendaraan bergolongan 2 dan 3, dikenakan biaya 11500
  4. Jika kendaraan bergolongan 4 dan 5, dikenakan biaya 16000
  5. Jika kendaraan bergolongan 6, tampilkan tarif tidak ditemukan
*/

// =====

/*
  El ingin pergi ke bioskop Lebah Ganteng
  1. Jika waktu sudah melewati waktu maghrib (jam 6 sore), el akan memilih istirahat saja
  2. Jika belum, el akan mengecek harga di website bioskop tersebut, daftar harganya adalah
    |  judul                   |  harga  |
    | Ketika for bertemu for   |  30000  |
    | Array vs Object          |  50000  |
    | Array multidimensiverse  |  40000  |
    | Dikejar Graded Challenge |  70000  |
  3. Jika uangnya tidak cukup untuk menonton salah satu film, maka el tidak jadi menonton
  4. Jika uangnya cukup, maka el akan memilih film yang harganya paling mahal sesuai uangnya
    contoh:
    uang el 100_000, maka akan memesan "Dikejar Graded Challenge"
    uang el 60_000, maka akan memesan "Array vs Object"
  5. Tampilkan sisa uangnya jika memesan tiket film
*/
