/*
  Osas akan login ke sosial media
  1. Jika input username atau password kosong, maka akan diminta untuk mengisi dulu
  2. Jika sudah mengisi maka akan dicek inputnya dengan data yang sudah teregister
  3. Username osas adalah "UVUVWEVWEVWE_ONYETENYEVWE_UGWEMUBWEM_OSAS"
  4. Passwordnya adalah 12345
  5. Jika username dan password tidak sesuai maka akan ada tampilan error
*/

/*
  Seorang pelangga bikitikipi ingin membeli sebuah produk
  1. Pelanggan wajib melakukan login dahulu,
    jika tidka login maka tampilkan: "anda harus login dahulu"
  2. Platinum user akan mendapat diskon 25%,
    tampilkan: "Hai pelanggan platinum, harga yang harus dibayar adalah Rp <harga yang sudah dipotong diskon>"
  3. Gold user akan mendapat diskon 20%,
    tampilkan: "Hai pelanggan gold, harga yang harus dibayar adalah Rp <harga yang sudah dipotong diskon>"
  4. Silver user akan mendapat diskon 15%,
    tampilkan: "Hai pelanggan silver, harga yang harus dibayar adalah Rp <harga yang sudah dipotong diskon>"
  5. Apabila user tidak termasuk tipe member diatas,
  tampilkan: "Halo, bayar sesuai harganya ya"
  
  contoh:
  harga produk 100.000 dan member Gold, maka harga yang harus dibayar adalah 80.000 
*/
