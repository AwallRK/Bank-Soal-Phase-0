/*
  4.
  Buat kondisi untuk mengecek kemana kamu pergi berdasarakn kendaraan yang dipunya
  | Kendaraan | Destinasi |
  | Motor     | Taman     |
  | Mobil     | Puncak    |
  | Kereta    | Monas     |
  | Pesawat   | Bali      |
  Ketika kendaraan tidak termasuk diatas maka akan stay di rumah aja

  example:
  nama = Fudi
  kendaraan = Motor
  output: Fudi akan menggunakan Motor untuk pergi ke Taman

  nama = Gidi
  kendaraan = Kuda
  output: Gidi akan di rumah saja
*/
let nama2 = "Lobi";
let kendaraan = "Pesawat";

/*
  5. Buat kondisi untuk mengecek inputan user
  validasi errornya adalah
  - apabila inputan kurang dari 5
  - apabila inputan termasuk falsy

  example:
  username = "Firefirefire"
  input = "a"
  output: Maaf Firefirefire minimum input adalah 5

  username = "projenletitgo"
  input = undefined
  output: Maaf projenletitgo input tidak jelas

  username = "Bolobolo"
  input = "abcdef"
  output: Silahkan masuk Bolobolo
*/
let username = "heisenberg";
let input = "?";
