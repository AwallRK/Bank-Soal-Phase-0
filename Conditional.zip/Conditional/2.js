/* 6. Buat kondisi untuk mengecek apakahSudahMakan true atau false */
let apakahSudahMakan = false;

/* 7. Buat kondisi untuk mengecek apakah apakahSebuahTruthy adalah sebuah truthy */
let apakahSebuahTruthy = "";

/* 8. Buat kondisi untuk mengecek apakah apakahSebuahFalsy adalah sebuah falsy */
let apakahSebuahFalsy = "adasdas";

/* 9. Buat kondisi untuk mengecek apakah tipe data angka adalah sebuah number atau bukan */
let angka = "1989";

/* 10. Buat kondisi untuk mengecek apakah kalimat memiliki panjang kurang dari 5 */
let kalimat = "abcdef";
