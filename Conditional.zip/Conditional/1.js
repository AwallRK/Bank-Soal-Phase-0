/* 1. Buat kondisi untuk mengecek apakah "warna" adalah putih atau hitam
 */
let warna = "";

/* 2. Buat kondisi untuk hewan selain berkaki empat */
let kakiHewan = 4;

/* 3. Buat kondisi untuk umur lebih dari 40 */
let umur = 50;

/* 4. Buat kondisi untuk nilai kurang dari 80 dan lebih dari 60 */
let nilai = 40;

/* 5. Buat kondisi untuk role adalah student atau role instruktur */
let role = "instruktur";
