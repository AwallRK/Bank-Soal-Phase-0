/* Buatlah sebuah object dengan key nama, umur dan nilai menggunakan function createObject. */
function createObject(data) {
  // Code
}
console.log(createObject(["Budi", 15, 80]));
/*
  Output
  {
    nama: "Budi",
    umur: 15,
    nilai: 80
  }
*/
console.log(createObject(["Ani", 18, 90]));
/*
  Output
  {
    nama: "Ani",
    umur: 18,
    nilai: 90
  }
*/
